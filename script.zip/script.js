document.addEventListener("DOMContentLoaded", function () {
  const button = document.getElementById("helloButton");
  const output = document.getElementById("output");

  button.addEventListener("click", function () {
    const time = new Date().toLocaleTimeString();
    output.textContent = `Hello! You clicked the button at ${time}.`;
  });
});
